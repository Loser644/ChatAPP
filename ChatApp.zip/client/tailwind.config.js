/** @type {import('tailwindcss').Config} */
export default {
  content: [
  "./index.html",
  "./src/**/*.{js,jsx,ts,tsx}",
  "../shared/**/*.{js,jsx,ts,tsx}", // if you have a shared package
  "../../packages/**/*.{js,jsx,ts,tsx}", // adjust based on your structure
],

  theme: { extend: {} },
  plugins: [],
};