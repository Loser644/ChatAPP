export default function App() {
  return (
    <div className="bg-red-500 h-screen flex items-center justify-center text-white">
      <h1 className="text-4xl font-bold">Hello Tailwind!</h1>
    </div>
  );
}
